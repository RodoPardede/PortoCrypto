import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:portocrypto/secondpage.dart';
import 'package:portocrypto/thirdpage.dart';

class ScreenFirst extends StatefulWidget {
  const ScreenFirst({super.key});

  @override
  _ScreenFirstState createState() => _ScreenFirstState();
}

class _ScreenFirstState extends State<ScreenFirst> {
  String inputNama = '';
  final db = FirebaseFirestore.instance;

  void updateData(String cryptoName, String buyPrice, String amount) {
    db.collection('cryptoData').add({
      'cryptoName': cryptoName,
      'buyPrice': buyPrice,
      'amount': amount,
    });
  }

  Future<void> removeCryptoData(String id) async {
    db.collection('cryptoData').doc(id).delete();
  }

  void updateNama(String nama) {
    setState(() {
      inputNama = nama;
    });
  }

  void navigateToScreenThird() async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => ScreenThird(updateNama: updateNama),
      ),
    );

    if (result != null) {
      setState(() {
        inputNama = result;
      });
    }
  }

  Widget renderTrailingText(final String buyPrice, final String amount) {
    final double total = double.parse(buyPrice) * double.parse(amount);

    return Text(total.toStringAsFixed(2));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('My Portofolio'),
        actions: [
          IconButton(
            icon: const Icon(Icons.add),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => ScreenSecond(updateData),
                ),
              );
            },
          ),
          IconButton(
            icon: const Icon(Icons.menu),
            onPressed: () {
              navigateToScreenThird();
            },
          ),
        ],
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const SizedBox(height: 20),
            Text(
              'Welcome, $inputNama',
              style: const TextStyle(fontSize: 16),
            ),
            const SizedBox(height: 20),
            const TotalPortfolioWidget(),
            Expanded(
              child: StreamBuilder(
                stream: db.collection('cryptoData').snapshots(),
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return const Center(
                      child: CircularProgressIndicator(),
                    );
                  }

                  if (snapshot.hasError) {
                    return const Center(
                      child: Text('Error'),
                    );
                  }

                  if (snapshot.hasData) {
                    final data = snapshot.data as QuerySnapshot;

                    return ListView.builder(
                      itemCount: data.size,
                      itemBuilder: (context, index) {
                        final cryptoData = data.docs[index];

                        return Dismissible(
                          key: Key(cryptoData['cryptoName']!),
                          onDismissed: (direction) async {
                            await removeCryptoData(cryptoData.id);
                          },
                          background: Container(
                            color: Colors.red,
                            alignment: Alignment.centerRight,
                            padding: const EdgeInsets.only(right: 20.0),
                            child:
                                const Icon(Icons.delete, color: Colors.white),
                          ),
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(10),
                            child: Container(
                              margin: const EdgeInsets.all(10),
                              padding: const EdgeInsets.all(10),
                              decoration: BoxDecoration(
                                border: Border.all(color: Colors.blue),
                              ),
                              child: ListTile(
                                title: Text('${cryptoData['cryptoName']}'),
                                subtitle: Text('${cryptoData['buyPrice']}'),
                                trailing: renderTrailingText(
                                    cryptoData['buyPrice'] ?? '0',
                                    cryptoData['amount'] ?? '0'),
                                leading: Text(
                                  '${cryptoData['amount']}',
                                ),
                              ),
                            ),
                          ),
                        );
                      },
                    );
                  }

                  return const SizedBox();
                },
              ),
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }
}

class TotalPortfolioWidget extends StatelessWidget {
  const TotalPortfolioWidget({super.key});

  double countTotalPorofolio(List<Map<String, dynamic>> cryptoDataList) {
    double totalPortfolio = 0;

    for (var crypto in cryptoDataList) {
      double buyPrice = double.parse(crypto['buyPrice'] ?? '0');
      double amount = double.parse(crypto['amount'] ?? '0');
      totalPortfolio += buyPrice * amount;
    }

    return totalPortfolio;
  }

  @override
  Widget build(BuildContext context) {
    final db = FirebaseFirestore.instance;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Total Portfolio',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        StreamBuilder<Object>(
            stream: db.collection('cryptoData').snapshots(),
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return const Center(
                  child: CircularProgressIndicator(),
                );
              }

              if (snapshot.hasError) {
                return const Center(
                  child: Text('Error'),
                );
              }

              final data = snapshot.data as QuerySnapshot;
              final cryptoDataList = data.docs
                  .map((e) => {
                        'cryptoName': e['cryptoName'],
                        'buyPrice': e['buyPrice'],
                        'amount': e['amount'],
                      })
                  .toList();

              return Text('Total: ${countTotalPorofolio(cryptoDataList)}');
            }),
      ],
    );
  }
}
