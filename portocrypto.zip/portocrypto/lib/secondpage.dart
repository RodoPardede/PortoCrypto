import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class ScreenSecond extends StatefulWidget {
  final Function(String, String, String) updateData;

  const ScreenSecond(this.updateData, {super.key});

  @override
  _ScreenSecondState createState() => _ScreenSecondState();
}

class _ScreenSecondState extends State<ScreenSecond> {
  final TextEditingController cryptoNameController = TextEditingController();
  final TextEditingController buyPriceController = TextEditingController();
  final TextEditingController amountController = TextEditingController();

  final filter = FilteringTextInputFormatter.allow(RegExp(r'^\d+\.?\d{0,2}$'));

  clearInput() {
    cryptoNameController.clear();
    buyPriceController.clear();
    amountController.clear();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('My Portofolio'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            TextFormField(
              controller: cryptoNameController,
              decoration: const InputDecoration(labelText: 'Crytocoin'),
            ),
            TextFormField(
              controller: buyPriceController,
              decoration: const InputDecoration(labelText: 'Buy Price'),
              keyboardType:
                  const TextInputType.numberWithOptions(decimal: true),
              inputFormatters: [filter],
            ),
            TextFormField(
              controller: amountController,
              decoration: const InputDecoration(labelText: 'Amount'),
              keyboardType:
                  const TextInputType.numberWithOptions(decimal: true),
              inputFormatters: [filter],
            ),
            const SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                ElevatedButton(
                  onPressed: () => clearInput(),
                  child: const Text('Reset'),
                ),
                ElevatedButton(
                  onPressed: () {
                    widget.updateData(
                      cryptoNameController.text,
                      buyPriceController.text,
                      amountController.text,
                    );

                    // Return data to the first screen
                    Navigator.pop(context, 'Data saved successfully');
                  },
                  child: const Text('Save'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
